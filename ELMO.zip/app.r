library(shiny)
library(MplusAutomation)
library(DT)
runApp("/Users/frisby/Box/Active/PhD Files/Research/LV Interactions/R Scripts/ELMO")




#deployApp("/Users/frisby/Box/Active/PhD Files/Research/LV Interactions/R Scripts/ELMO")

